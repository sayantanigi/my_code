import React, { useState } from "react";
import { ImageBackground, StyleSheet, Text, TextInput, View } from 'react-native';
import { FontAwesome } from "@expo/vector-icons";
import { useNavigation } from "@react-navigation/native";
import { useUserStore } from "../stores/users";



export default function Login() {
    const Navigation = useNavigation<any>()

    // const [user, setUser] = useUserStore()

    const [passwordShow, setPasswordshow] = useState(false);



    function gotoRegistration() {
        Navigation.navigate('Registration')
    }
    function gotoDashboard() {
        Navigation.navigate('Root')
    }
 

    return (
        <View style={styles.container}>
            <ImageBackground source={require("../assets/splashbg.jpg")} resizeMode="cover" style={styles.image}>
                <View style={styles.textinputbackground}>
                    <TextInput style={styles.textinput}
                        returnKeyType="next"
                        autoCapitalize="none"
                        textContentType="emailAddress"
                        keyboardType="email-address" />

                    <View style={styles.rowcontainer}>
                        <TextInput style={styles.textinput}
                            returnKeyType="done"
                            autoCapitalize="none"
                            textContentType="password"
                            keyboardType="email-address" />
                        <FontAwesome onPress={function () { setPasswordshow(!passwordShow) }} name={passwordShow ? "eye-slash" : "eye"} style={{ fontSize: 20, color: "#9c9c9c", marginHorizontal: 25, marginTop: 25, marginLeft: "auto" }}></FontAwesome>


                    </View>
                    <Text style={styles.forgot}>Forgot password?</Text>
                    <Text onPress={gotoDashboard} style={styles.buttontext}>
                        Login
                    </Text>
                    <View style={{flexDirection:'row'}}>
                    <Text style={styles.signup}>Don't have an account?</Text>
                    <Text onPress={gotoRegistration} style={styles.signuptxt}> Sign Up</Text>
                   

                    </View>
                </View>



            </ImageBackground>

        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        width: '100%',
        flexDirection: 'column',
    },

    rowcontainer: {
        width: '100%',
        height: 45,
        flexDirection: 'row',
    },
    image: {
        flex: 1,
        justifyContent: 'center',
    },
    text: {
        color: 'white',
        fontSize: 42,
        lineHeight: 84,
        fontWeight: 'bold',
        textAlign: 'center',
        backgroundColor: '#000000',
    },

    textinputbackground: {
        justifyContent: 'center',
        alignItems: 'center',
        flex: 1,
        width: '100%',
        height: 45,


    },

    textinput: {
        marginTop: 10,
        backgroundColor: '#F8F9F9',
        marginLeft: 20,
        marginRight: 20,
        paddingStart: 5,
        width: '90%',
        height: 45,
        borderRadius: 10,
        borderWidth: 1

    },
    forgot: {
        padding:4,
        marginTop: 10,
        alignContent: 'flex-end',
        width: '90%',
        textAlign: "right",
        fontWeight: 'bold'
    },

    buttontext: {
        marginTop: 5,
        alignItems: 'flex-end',
        backgroundColor: '#000000',
        color: '#ffffff',
        textAlign: 'center',
        fontWeight: "bold",
        width: '90%',
        padding: 10,
        borderRadius: 10,
        borderWidth: 1

    },
    signup: {
        marginTop: 10,
        alignContent: 'flex-end',
        width: '60%',
        textAlign: "right",
        fontWeight: 'bold'
    },
    signuptxt: {
        marginTop: 10,
        fontSize:15,
        alignContent: 'center',
        width: '15%',
        color: '#F91506',
        textAlign: "right",
        fontWeight: 'bold'
    }

});

