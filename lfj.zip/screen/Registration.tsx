import React, { useState } from "react";
import { Image,ImageBackground, StyleSheet, Text, TextInput, View } from 'react-native';
import { FontAwesome } from "@expo/vector-icons";


export function Registration(){
    const [passwordShow, setPasswordshow] = useState(false);

    return (
        <View style={styles.container}>
            <ImageBackground source={require("../assets/splashbg.jpg")} resizeMode="cover" style={styles.image}>
                <View style={styles.textinputbackground}>
                
                <TextInput style={styles.textinput}
                        returnKeyType="next"
                        autoCapitalize="none"
                        placeholder="Name"
                        textContentType="emailAddress"
                        keyboardType="email-address" />
                    <TextInput style={styles.textinput}
                        returnKeyType="next"
                        autoCapitalize="none"
                        placeholder="Email"
                        textContentType="emailAddress"
                        keyboardType="email-address" />

                    <View style={styles.rowcontainer}>
                        <TextInput style={styles.textinput}
                            returnKeyType="done"
                            autoCapitalize="none"
                            placeholder="Password"
                            textContentType="password"
                            keyboardType="email-address" />
                        <FontAwesome onPress={function () { setPasswordshow(!passwordShow) }} name={passwordShow ? "eye-slash" : "eye"} style={{ fontSize: 20, color: "#9c9c9c", marginHorizontal: 25, marginTop: 25, marginLeft: "auto" }}></FontAwesome>


                    </View>
                    <View style={{marginTop:10}}>



                    </View>

                    <View style={styles.rowcontainer}>
                        <TextInput style={styles.textinput}
                            returnKeyType="done"
                            autoCapitalize="none"
                            placeholder="Confirm Password"
                            textContentType="password"
                            keyboardType="email-address" />
                        <FontAwesome onPress={function () { setPasswordshow(!passwordShow) }} name={passwordShow ? "eye-slash" : "eye"} style={{ fontSize: 20, color: "#9c9c9c", marginHorizontal: 25, marginTop: 25, marginLeft: "auto" }}></FontAwesome>


                    </View>
                    
                    <View style={styles.SectionStyle}>
    <Image
        source={require('../assets/america.png')} //Change your icon image here
        style={styles.ImageStyle}
    />
    <Text  style={{fontSize:15,fontWeight:'bold'}}>+1</Text>

    <TextInput
        style={{ flex: 1,padding:2 }}
        placeholder="Enter Mobile number"
        keyboardType='numeric'
        underlineColorAndroid="transparent"
    />
</View>



                 
                    <Text style={styles.buttontext}>
                    Register
                    </Text>

                   
                    <View style={{flexDirection:'row'}}>
                    <Text style={styles.signup}>All ready have an account?</Text>
                    <Text style={styles.signuptxt}> Login</Text>
                    </View>


                </View>



            </ImageBackground>

        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        width: '100%',
        flexDirection: 'column',
    },

    rowcontainer: {
      
        width: '100%',
        height: 45,
        flexDirection: 'row',
    },
    image: {
        flex: 1,
        justifyContent: 'center',
    },
    text: {
        color: 'white',
        fontSize: 42,
        lineHeight: 84,
        fontWeight: 'bold',
        textAlign: 'center',
        backgroundColor: '#000000',
    },

    textinputbackground: {
       justifyContent: 'center',
        alignItems: 'center',
        flex: 1,
        width: '100%',
        height: 45,


    },

    textinput: {
        marginTop: 10,
        backgroundColor: '#F8F9F9',
        marginLeft: 20,
        marginRight: 20,
        paddingStart: 5,
        width: '90%',
        height: 45,
        borderRadius: 10,
        borderWidth: 1

    },
    forgot: {
        padding:4,
        marginTop: 10,
        alignContent: 'flex-end',
        width: '90%',
        textAlign: "right",
        fontWeight: 'bold'
    },

    buttontext: {
        marginTop: 10,
        alignItems: 'flex-end',
        backgroundColor: '#000000',
        color: '#ffffff',
        textAlign: 'center',
        fontWeight: "bold",
        width: '90%',
        padding: 10,
        borderRadius: 10,
        borderWidth: 1

    },
    signup: {
        marginTop: 10,
        alignContent: 'flex-end',
        width: '60%',
        textAlign: "right",
        fontWeight: 'bold'
    },
    signuptxt: {
        marginTop: 10,
        fontSize:15,
        alignContent: 'center',
        width: '15%',
        color: '#F91506',
        textAlign: "right",
        fontWeight: 'bold'
    },
    SectionStyle: {
        width:"90%",
        marginTop:20,
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#fff',
        borderWidth: 1,
        borderColor: '#000',
        height: 45,
        borderRadius: 10,
       
    },
    ImageStyle: {
        padding: 10,
        margin: 5,
        height: 25,
        width: 25,
        resizeMode: 'stretch',
        alignItems: 'center',
    }

});
