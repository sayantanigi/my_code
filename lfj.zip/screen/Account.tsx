import React from "react";
import { SafeAreaView, StyleSheet, View, Text, ImageBackground, Dimensions, TouchableOpacity, TextInput, FlatList, ScrollView, Image } from "react-native";

import { FontAwesome } from "@expo/vector-icons";
export default function Account() {

    return (
        <SafeAreaView style={styles.container}>
            <View style={styles.header}>

                <View style={{ flexDirection: 'row', padding: 5, flex: 1, alignContent: 'flex-start',margin:10 }}>
                    <Image
                        source={require('../assets/no_picture.png')}
                        style={styles.roundImage}
                    />

                    <Text style={styles.text}> User Name</Text>
                </View>


            </View>

            <ScrollView style={styles.content}>
               
              <View style={{flexDirection:'row',padding:10,marginTop:10}}>

              <FontAwesome name="shopping-bag" style={{ fontSize: 25, color: "#000000", marginHorizontal: 2 }}></FontAwesome>
              <Text style={{fontSize:15}}> Order</Text>

              </View>
              <View style={{flexDirection:'row',padding:10,marginTop:10}}>

<FontAwesome name="heart" style={{ fontSize: 25, color: "#000000", marginHorizontal: 2 }}></FontAwesome>
<Text style={{fontSize:15}}> Your Favourites</Text>

</View>
<View style={{flexDirection:'row',padding:10,marginTop:10,}}>

<FontAwesome name="home" style={{ fontSize: 25, color: "#000000", marginHorizontal: 2 }}></FontAwesome>
<Text style={{fontSize:15}}> Add Address</Text>

</View>
<View style={{flexDirection:'row',padding:10,marginTop:10}}>

<FontAwesome name="cog" style={{ fontSize: 25, color: "#000000", marginHorizontal: 2 }}></FontAwesome>
<Text style={{fontSize:15}}> Settings</Text>

</View>
<View style={{flexDirection:'row',padding:10,marginTop:10}}>

<FontAwesome name="lock" style={{ fontSize: 25, color: "#000000", marginHorizontal: 2 }}></FontAwesome>
<Text style={{fontSize:15}}> Change Password</Text>

</View>
            </ScrollView>

            <View style={styles.footer}>
                {/* Footer content */}
            </View>
        </SafeAreaView>
    );
};
const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
    },
    header: {
        flexDirection: 'row',
        height: 100,
        borderBottomWidth: 5,
        borderColor:"#f3f1f155",
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.2,
        shadowRadius: 2,
        elevation: 3,
        backgroundColor: '#f2f2f2',
        justifyContent: 'center',
        alignItems: 'center',
    },
    content: {
        marginLeft:10,
        flex: 1,
        backgroundColor: '#fff',
    },
    footer: {
        height: 80,
        backgroundColor: '#f2f2f2',
        justifyContent: 'center',
        alignItems: 'center',
    },
    roundImage: {
        marginTop: 20,
        width: 40,
        height: 40,
        borderRadius: 100,
    },

    text: {
        marginTop: 30,

        fontWeight: 'bold',

        textAlign: 'center',

        fontSize: 15,
        color: '#000000',

    }
});






