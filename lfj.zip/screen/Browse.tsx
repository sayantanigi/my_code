import { SafeAreaView, Image, StyleSheet, View, Text, ImageBackground, Dimensions, TouchableOpacity, TextInput, FlatList, ScrollView } from "react-native";

import React, { useEffect, useState } from "react";
import { FontAwesome } from "@expo/vector-icons";
import { BASEURL } from "../stores/Api";


export interface Category {
  id: string
  category_name: string
  category_image: string
  image_url: string
  status: string
}



export default function Browse() {

  const [letestcategory, setletestcategory] = useState(Array<Category>())
  const handleSearch = () => {
    // Perform search functionality
   
  };
  useEffect(() => {
    fetchLetestCategory()
   
}, []);
  
async function fetchLetestCategory() {

  let response = await fetch(`${BASEURL}food_category_list`, {
      method: "GET",

  })

  let json = await response.json()
  setletestcategory(json.result)
   // console.log(json.result)



}

  return (
    <SafeAreaView style={{flex:1,margin:5}}>
<View style={styles.container}>
        <TextInput
          style={styles.input}
          placeholder="Search"
         
        />

        <TouchableOpacity style={styles.button} onPress={handleSearch}>
          <FontAwesome
            style={{
              fontSize: 20
            }}
            name="search" />
        </TouchableOpacity>

        
      </View>

    
     <FlatList
     showsVerticalScrollIndicator={false}
     showsHorizontalScrollIndicator={false}
     data={letestcategory}
     renderItem={({ item }) => (
       <View 
       
       
       style={{flexGrow:1,width:'50%',padding:4 }}>

         
         <Image style={styles.imageBackground} source={{ uri: item.image_url }} />
         <Text style={styles.text}>{item.category_name}</Text>
       </View>
     )}
   
     numColumns={2}
    
     
   />
   

    </SafeAreaView>
  );
}


const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#e8e8e8',
    borderRadius: 8,
    paddingVertical: 8,
    marginTop: 25,
    paddingHorizontal: 12,
  },
  input: {
    flex: 1,
    height: 40,
    marginRight: 8,
    backgroundColor: 'white',
    borderRadius: 8,
    paddingHorizontal: 8,
  },
  button: {
    backgroundColor: '#faf7f7',
    borderRadius: 8,
    paddingVertical: 8,
    paddingHorizontal: 16,
  },
  buttonText: {
    color: 'white',
    fontWeight: 'bold',
  },
  imageBackground: {
    borderTopRightRadius:20,
    borderTopLeftRadius:20,
    justifyContent: 'center',
    alignItems: 'center',
    width:'100%',
    height: 100,
},

text: {
 
  numberOfLines: 1,
  borderBottomRightRadius: 20,
  borderBottomLeftRadius: 20,
  padding: 4,
  fontWeight:'bold',
  backgroundColor: '#ffffff',
  textAlign: 'center',
  textAlignVertical: 'bottom',
  fontSize: 15,
  color: '#000000',

}
});

