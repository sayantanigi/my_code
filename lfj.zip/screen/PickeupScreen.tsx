import { Text, Dimensions, ImageBackground, Modal, ScrollView, StyleSheet, View } from "react-native";
import SearchBar, { FilterButton, SearchbarEditable } from "../components/SearchBar";
import React, { useEffect, useState } from "react";
import MapView, { Marker, Region } from 'react-native-maps';
import * as Location from 'expo-location';
import { BASEURL } from "../stores/Api";
import { FontAwesome } from "@expo/vector-icons";
export interface ResturantList {
    id: string
    distance: string
    user_id: string
    name: string
    country: string
    state: string
    city: string
    avgCost: string
    currency: string
    currency_symbol: string
    address: string
    latitude: string
    longitude: string
    createdDate: string
    status: string
    average_rating: string
    images: string
}


export default function PickeupScreen() {
    const [searchLabel, setSearchLabel] = useState("")
    const [isSearchOpen, setisSearchOpen] = useState(false)
    const [getResturantlist, setResturantlist] = useState(Array<ResturantList>())
    const [region, setRegion] = useState<Region | undefined>(undefined);
    const [errorMessage, setErrorMessage] = useState('');

    useEffect(() => {

        fetchResturantList();
        (async () => {
            let { status } = await Location.requestForegroundPermissionsAsync();
            if (status !== 'granted') {
                setErrorMessage('Permission to access location was denied');
                return;
            }

            let location = await Location.getCurrentPositionAsync({});
            const { latitude, longitude } = location.coords;
            setRegion({
                latitude,
                longitude,
                latitudeDelta: 0.0922,
                longitudeDelta: 0.0421,
            });
        })();
    }, []);

    function handleSearch() {
        setisSearchOpen(true)
    }

    async function fetchResturantList() {



        const formData = new FormData();
        formData.append('latitude', '22.57')
        formData.append('longitude', '88.36')
        formData.append('keyword', '')
        formData.append('category_name', '')
        formData.append('sign_filtering[]', '0')

        console.log(formData)
        let response = await fetch(BASEURL + "restaurantList", {
            method: "POST",

            headers: {

                'Content-Type': 'multipart/form-data',

            },

            body: formData,
        })

        let json = await response.json()
        setResturantlist(json.list)
        // console.log(json.list)
    }




    return (
        <ScrollView style={styles.container}>
            <View style={styles.searchWrapper}>
                <SearchBar
                    style={{ width: "100%" }}
                    onPress={handleSearch}
                    label={searchLabel}
                />
            </View>

            <View style={styles.container}>
                {region && (
                    <MapView style={styles.map}
                        region={region}>
                        <Marker coordinate={region} title="My Location" />
                    </MapView>
                )}
            </View>

            <View style={styles.container}>
                <ScrollView
                    alwaysBounceVertical
                    showsHorizontalScrollIndicator={false}
                    pagingEnabled={true}>
                    {
                        getResturantlist?.map((item: ResturantList, index: number) => {
                            return (

                                <View style={styles.containeresturant}>

                                    <ImageBackground
                                        key={index} source={{ uri: item.images }}
                                        style={styles.imagehight}
                                        imageStyle={styles.image}>

                                    </ImageBackground>
                                    <Text style={styles.textresturant}>{item.name}</Text>
                                    <View style={{ flexDirection: 'row', height: 25, width: '100%' }}>
                                        <FontAwesome name="map-marker" style={{ fontSize: 20, color: "#000000", marginHorizontal: 2 }}></FontAwesome>
                                        <Text style={styles.textresturant}>{item.address}</Text>

                                    </View>


                                </View>

                            )


                        })
                    }


                </ScrollView>
            </View>



            <Modal
                animationType='slide'
                onRequestClose={() => setisSearchOpen(false)}
                visible={isSearchOpen}>
                <View style={styles.searchPopup}
                >
                    <View style={styles.searchWrapper}>
                        <SearchbarEditable
                            onBackButtonPress={() => setisSearchOpen(false)}
                        />
                    </View>
                </View>
            </Modal>
        </ScrollView>
    )
}
const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: "#fff"
    },
    searchWrapper: {
        padding: 8,
        flexDirection: "row",
        flexWrap: "wrap",
        justifyContent: "space-between"
    },
    searchPopup: {
        padding: 8,
        flex: 1
    }, map: {
        width: Dimensions.get('window').width,
        height: 250,
    },

    containeresturant: {
        flex: 1,
        borderWidth: 5,
        margin: 2,
        borderColor: '#faf7f7',
        justifyContent: 'flex-end',
        alignItems: 'flex-start',
        borderRadius: 10,

    },
    image: {

        resizeMode: 'cover',

    },
    imageBackground: {
        margin: 5,
        width: 150,
        height: 100,
        justifyContent: 'flex-end',
    },
    imagehight: {
        margin: 1,
        width: '100%',
        height: 150,
        justifyContent: 'flex-end',
    },
    textresturant: {
        numberOfLines: 1,
        padding: 5,
        fontWeight: 'bold',
        textAlignVertical: 'bottom',
        fontSize: 15,
        color: '#000000',

    },
})