import { Modal, SafeAreaView, ScrollView, StyleSheet, View, Text, ImageBackground, Dimensions, Pressable } from "react-native";
import SearchBar, { FilterButton, SearchbarEditable } from "../components/SearchBar";
import React, { useEffect, useState } from "react";
import { BASEURL } from "../stores/Api";
import { FontAwesome } from "@expo/vector-icons";
import { useNavigation } from "@react-navigation/native";


export interface Category {
    image: any;
    id: string
    category_name: string
    category_image: string
    image_url: string
    status: string
}
export interface ResturantList {
    id: string
    distance: string
    user_id: string
    name: string
    country: string
    state: string
    city: string
    avgCost: string
    currency: string
    currency_symbol: string
    address: string
    latitude: string
    longitude: string
    createdDate: string
    status: string
    average_rating: string
    images: string
}

export default function DeliveryScreen() {
    const [searchLabel, setSearchLabel] = useState("")
    const [isSearchOpen, setisSearchOpen] = useState(false)
    const [letestcategory, setletestcategory] = useState(Array<Category>())
    const [getResturantlist, setResturantlist] = useState(Array<ResturantList>())
    const  screenwidth  = Dimensions.get('window');
    const Navigation = useNavigation<any>()

    useEffect(() => {

        fetchLetestCategory()
        fetchResturantList()
    }, []);




    async function fetchLetestCategory() {

        let response = await fetch(`${BASEURL}food_category_list`, {
            method: "GET",

        })

        let json = await response.json()
        setletestcategory(json.result)
        //  console.log(json.result)



    }
    async function fetchResturantList() {



        const formData = new FormData();
        formData.append('latitude', '22.57')
        formData.append('longitude', '88.36')
        formData.append('keyword', '')
        formData.append('category_name', '')
        formData.append('sign_filtering[]', '0')

        console.log(formData)
        let response = await fetch(BASEURL + "restaurantList", {
            method: "POST",

            headers: {

                'Content-Type': 'multipart/form-data',

            },

            body: formData,
        })

        let json = await response.json()
        setResturantlist(json.list)
        // console.log(json.list)
    }



    function handleFilter() {

    }

    function handleSearch() {
        setisSearchOpen(true)
    }

function gotoDetails(){

    Navigation.navigate('RestaurantDetails')

}
   


    return (


        <ScrollView style={styles.container}>
            <View style={styles.searchWrapper}>
                <SearchBar
                    onPress={handleSearch}
                    label={searchLabel}
                />
                <FilterButton
                    onPress={handleFilter} />
            </View>
            <Modal
                animationType='slide'
                onRequestClose={() => setisSearchOpen(false)}
                visible={isSearchOpen}>
                <View style={styles.searchPopup}
                >
                    <View style={styles.searchWrapper}>
                        <SearchbarEditable
                            onBackButtonPress={() => setisSearchOpen(false)}
                        />
                    </View>
                </View>
            </Modal>

            <SafeAreaView style={{ flex: 1, backgroundColor: '#fff' }}>
                <View style={styles.container}>
                    <View style={styles.header}>
                        <View style={{ flexDirection: 'row' }}>

                            <ScrollView
                                horizontal
                                showsHorizontalScrollIndicator={false}
                                pagingEnabled={true}>
                                {
                                    letestcategory?.map((item: Category, index: number) => {
                                        return (

                                            <View style={styles.containerone}>

                                                <ImageBackground
                                                    key={index} source={{ uri: item.image_url }}
                                                    style={styles.imageBackground}
                                                    imageStyle={styles.image}>
                                                    <Text style={styles.text}>{item.category_name}</Text>
                                                </ImageBackground>
                                            </View>

                                        )


                                    })
                                }


                            </ScrollView>



                        </View>
                    </View>
                    <ScrollView
                        contentContainerStyle={styles.content}>

                        <ScrollView
                            alwaysBounceVertical
                            showsHorizontalScrollIndicator={false}
                            pagingEnabled={true}>
                            {
                                getResturantlist?.map((item: ResturantList, index: number) => {
                                    return (


  <Pressable onPress={gotoDetails}>
<View style={styles.containeresturant}>

<ImageBackground
    key={index} source={{ uri: item.images }}
    style={styles.imagehight}
    imageStyle={styles.image}>

</ImageBackground>
<Text style={styles.textresturant}>{item.name}</Text>
<View style={{ flexDirection: 'row', height: 25, width: '100%' }}>
    <FontAwesome name="map-marker" style={{ fontSize: 20, color: "#000000", marginHorizontal: 2 }}></FontAwesome>
    <Text style={styles.textresturant}>{item.address}</Text>

</View>


</View>
                                        </Pressable>

                                        

                                    )


                                })
                            }


                        </ScrollView>

                    </ScrollView>
                    <View style={styles.footer}>

                        <ScrollView
                            horizontal
                            showsHorizontalScrollIndicator={false}
                            pagingEnabled={true}>
                            {
                                letestcategory?.map((item: Category, index: number) => {
                                    return (

                                        <View style={styles.containerone}>

                                            <ImageBackground
                                                key={index} source={{ uri: item.image_url }}
                                                style={styles.imageBackground}
                                                imageStyle={styles.image}>
                                                <Text style={styles.text}>{item.category_name}</Text>
                                            </ImageBackground>
                                        </View>

                                    )


                                })
                            }


                        </ScrollView>
                    </View>
                </View>







            </SafeAreaView>

        </ScrollView>


    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: "#fff"
    },
    searchWrapper: {
        padding: 8,
        flexDirection: "row",
        flexWrap: "wrap",
        justifyContent: "space-between"
    },
    searchPopup: {
        padding: 8,
        flex: 1
    },

    containerone: {
        flex: 1,
        justifyContent: 'flex-end',
        alignItems: 'center',

    },
    containeresturant: {
        flex: 1,
        borderWidth: 5,
        margin: 2,
        borderColor: '#faf7f7',
        justifyContent: 'flex-end',
        alignItems: 'flex-start',
        borderRadius: 10,

    },
    image: {

        resizeMode: 'cover',

    },
    text: {
        numberOfLines: 1,
        padding: 4,
        backgroundColor: 'rgba(0, 0, 0, 0.5)',
        textAlign: 'center',
        textAlignVertical: 'bottom',
        fontSize: 15,
        color: '#ffffff',

    },
    textresturant: {
        numberOfLines: 1,
        padding: 5,
        fontWeight: 'bold',
        textAlignVertical: 'bottom',
        fontSize: 15,
        color: '#000000',

    },
    imageBackground: {
        margin: 5,
        width: 150,
        height: 100,
        justifyContent: 'flex-end',
    },
    imagehight: {
        margin: 1,
        width: '100%',
        height: 150,
        justifyContent: 'flex-end',
    },

    header: {
        height: 130,
        margin: 5,
        justifyContent: 'center',
        alignItems: 'center',
    },
    content: {
        flex: 1,
        margin: 5
    },
    footer: {
        marginLeft: 5,
        justifyContent: 'center',
        alignItems: 'center',
    },

   
})