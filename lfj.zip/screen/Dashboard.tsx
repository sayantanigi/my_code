import { useWindowDimensions } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { TabView, SceneMap, TabBar } from 'react-native-tab-view';
import {
  View,
  StyleSheet,
} from 'react-native';
import { useState } from 'react';
import { StatusBar } from 'expo-status-bar';
import DeliveryScreen from './DeliveryScreen';
import PickeupScreen from './PickeupScreen';



const renderScene = SceneMap({
  first: DeliveryScreen,
  second: PickeupScreen,
});

export default function Dashboard() {
  const layout = useWindowDimensions();
  const [index, setIndex] = useState(0);
  const [routes] = useState([
    { key: 'first', title: 'Delivery' },
    { key: 'second', title: 'Pickup' },
  ]);


  return (
    <SafeAreaView style={{ backgroundColor: '#ffffff' }}>
      <StatusBar
        backgroundColor={"#217b45"}
        style='light'
      />
      <View style={styles.tabBar}>
        <TabView
          navigationState={{ index, routes }}
          renderScene={renderScene}
          onIndexChange={setIndex}
          swipeEnabled={false}
          initialLayout={{ width: layout.width }}
          renderTabBar={props => (
            <TabBar {...props}
              indicatorStyle={{ backgroundColor: "#464646" }}
              style={{ backgroundColor: '#32B767' }} />
          )}

        />
      </View>
    </SafeAreaView>


  );
}

const styles = StyleSheet.create({
  tabBar: {
    height: "100%"


  },
  indicatorStyle: {

    padding: 10,
    marginBottom: 0,
  },

  tabItem: {
    flex: 1,
    alignItems: 'center',
    padding: 16,
  },
  searchWrapper: {
    padding: 8,
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between"
  },
  searchPopup: {
    padding: 8,
    flex: 1
  }
});