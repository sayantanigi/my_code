import { SafeAreaView, StyleSheet, View, Text, ImageBackground, Dimensions, TouchableOpacity, TextInput, FlatList, ScrollView, Image, BackHandler, Pressable } from "react-native";

import { FontAwesome } from "@expo/vector-icons";

import { useNavigation, useIsFocused } from "@react-navigation/native";
import MapView, { Marker } from "react-native-maps";

const latitude = 23.533440;
const longitude = 87.321930;
export default function RestaurantDetails({ navigation }: any) {

    function gotoback() {
        navigation.navigate("Root")
    }




    return (
        <SafeAreaView style={styles.container}>
            <View style={styles.header}>
                <Pressable onPress={gotoback} style={{ flexDirection: 'row', padding: 5, flex: 1, alignContent: 'center', marginTop: 30 }}>

                    <FontAwesome name="long-arrow-left" style={{ fontSize: 25, color: "#000000", marginHorizontal: 2 }}></FontAwesome>
                    <Text style={{ fontSize: 15 }}> Details</Text>
                </Pressable>

            </View>

            <ScrollView style={styles.content}>

                <View style={styles.container}>
                    <MapView
                        style={styles.map}
                        initialRegion={{
                            latitude,
                            longitude,
                            latitudeDelta: 0.0922,
                            longitudeDelta: 0.0421,
                        }}
                    >
                        <Marker coordinate={{ latitude, longitude }} />
                    </MapView>
                </View>


            </ScrollView>

            <View style={styles.footer}>
                {/* Footer content */}
            </View>
        </SafeAreaView>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
    },
    header: {
        flexDirection: 'row',
        height: 80,
        borderBottomWidth: 5,
        borderColor: "#f3f1f155",
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.2,
        shadowRadius: 2,
        elevation: 3,
        backgroundColor: '#f2f2f2',
        justifyContent: 'center',
        alignItems: 'center',
    },
    content: {
        marginLeft: 10,
        flex: 1,
        backgroundColor: '#fff',
    },
    footer: {
        height: 80,
        backgroundColor: '#f2f2f2',
        justifyContent: 'center',
        alignItems: 'center',
    },
    roundImage: {
        marginTop: 20,
        width: 40,
        height: 40,
        borderRadius: 100,
    },

    text: {
        marginTop: 30,

        fontWeight: 'bold',

        textAlign: 'center',

        fontSize: 15,
        color: '#000000',

    },
    map: {
        width: Dimensions.get('window').width,
        height: 250,
    },
});

function goBack() {
    throw new Error("Function not implemented.");
}
