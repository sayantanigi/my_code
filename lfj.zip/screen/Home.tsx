import { Text } from "react-native"


export default function Home() {
    return(
        <Text>
            Him from Home
        </Text>
    )
}