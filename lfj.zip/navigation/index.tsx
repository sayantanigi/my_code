import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { FontAwesome } from '@expo/vector-icons';
import Login from "../screen/Login";
import Home from "../screen/Home";
import { Registration } from "../screen/Registration";

import React from "react";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import Dashboard from "../screen/Dashboard";
import Colors from '../constants/Colors';
import Browse from "../screen/Browse";
import Account from "../screen/Account";
import RestaurantDetails from "../screen/RestaurantDetails";

export function RootNavigation() {
    return(
        <NavigationContainer>
            <Root/>
        </NavigationContainer>
    )
}

const Stack = createNativeStackNavigator();
const defaultOptions: any = {
    headerShown: false,
   // presentation: 'modal'
  }
function Root() {
  return (
    <Stack.Navigator initialRouteName="Login" >
      <Stack.Screen name="Home" component={Home}  options = {defaultOptions}/>
      <Stack.Screen name="Root" component={MyTabs} options={defaultOptions} />
      <Stack.Screen name="Login" component={Login}  options = {defaultOptions}/>
      <Stack.Screen name="Registration" component={Registration}  options = {defaultOptions}/>
      <Stack.Screen name="RestaurantDetails" component={RestaurantDetails}  options = {defaultOptions}/>
      
    </Stack.Navigator>
  );
}

const Tab = createBottomTabNavigator();
function MyTabs() {


  return (


    
    <Tab.Navigator   
    
    initialRouteName="Dashboard"
    
  
    
    >
   
      <Tab.Screen
       name="Home"
       component={Dashboard}
        options={({ navigation }) => ({
        title: 'Home',
        tabBarIcon: ({ color }) => <TabBarIcon name="home" color={color} />,
        headerShown: false,
        tabBarActiveTintColor: '#32B767',
        tabBarInactiveTintColor: 'gray',
        
      })}/>
      <Tab.Screen
       name="Browse"
       component={Browse}
        options={({ navigation }) => ({
        title: 'Browse',
        tabBarIcon: ({ color }) => <TabBarIcon name="search" color={color} />,
        headerShown: false,
        tabBarActiveTintColor: '#32B767',
        tabBarInactiveTintColor: 'gray',
        
      })}/>
       <Tab.Screen
       name="Carts"
       component={Dashboard}
        options={({ navigation }) => ({
        title: 'Carts',
        tabBarIcon: ({ color }) => <TabBarIcon name="shopping-cart" color={color} />,
        headerShown: false,
        tabBarActiveTintColor: '#32B767',
        tabBarInactiveTintColor: 'gray',
        
      })}/>
       <Tab.Screen
       name="Accounts"
       component={Account}
        options={({ navigation }) => ({
        title: 'Accounts',
        tabBarIcon: ({ color }) => <TabBarIcon name="user" color={color} />,
        headerShown: false,
        tabBarActiveTintColor: '#32B767',
        tabBarInactiveTintColor: 'gray',
        
      })}/>
    </Tab.Navigator>
  );
}

function TabBarIcon(props: {
  name: React.ComponentProps<typeof FontAwesome>['name'];
  color: string;
}) {
  return <FontAwesome size={25} style={{ marginBottom: -3 }} {...props} />;
}