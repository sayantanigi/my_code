import { atom, useAtom } from "jotai";


export const BASEURL = "https://www.localfood-joints.com/restapi/api/"
export let UserId = atom("")
