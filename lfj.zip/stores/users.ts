import { atom, useAtom } from "jotai";

export interface User {
    userId: string
    name: string
    email: string
    phone: string
    phone_full: string
    phone_code: string
    phone_country: string
    phone_st_country: string
    address: string
    latitude: string
    longitude: string
    profilePic: string
    email_verified: string
    phone_verified: string
    status: string
}
export const userStore = atom<User | null>(null)

export const useUserStore = () => useAtom(userStore)