import { RootNavigation } from './navigation';

export default function App() {
  return (
    <RootNavigation/>
  );
}
